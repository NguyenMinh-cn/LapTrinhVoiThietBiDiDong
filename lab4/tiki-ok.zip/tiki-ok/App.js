import { Text, View, StyleSheet, TouchableOpacity, Image,Alert } from 'react-native';

import {useState, useEffect} from "react";
function handleClick() {
  
  
  }
export default function App() {

  const [total, setTotal] = useState(0);
  const [tamtinh, setTamTinh] = useState(0);
  const [sl, setSL] = useState(1);
  function handleInc() {
      setSL(sl-1);
      setTamTinh(sl*140000);
    }
    useEffect(()=>{
      setTamTinh(tamtinh => sl * 140000);
      setTotal(tamtinh)
    }, [sl]);
    
  return (

    <View  style={styles.container}>
        <View style={styles.thanhtoan}>
          <View style={{flexDirection: "column"}}>
            <Image style={{margin: 20}} source={require("./assets/book.png")} />
          </View>
          <View >
            <Text style={styles.title} >Nguyên hàm tích phân và ứng dụng</Text>
            <Text style={styles.title}>Cung cấp bởi Tiki Trading</Text>
            <Text style={styles.pricenew}>141.800 đ</Text>
            <Text style={styles.priceold}>150.000 đ</Text>
            <View  style={{flexDirection: "row"}}>
              <TouchableOpacity onPress={handleInc}>-</TouchableOpacity>
              <Text>{sl}</Text>
              <TouchableOpacity onPress={e => setSL(sl+1)}>+</TouchableOpacity>
            </View>
          </View>
          
        </View>
      <View  style={[styles.thanhtoan, {justifyContent: "space-between"}]}>
            <Text>Tạm tính</Text>
            <Text>{tamtinh}</Text>
      </View>
      <View style={{flex:2}}>
      <Text style={{fontWeight: "bold"}}>
        Thành tiền
      </Text>
      <Text style={{fontWeight: "bold"}}>
        {total}
      </Text>
        <TouchableOpacity  style={styles.button}>
        <Text style={{color: "white", fontWeight: "bold"}}>TIẾN HÀNH ĐẶT HÀNG</Text>
        </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  button:{
    backgroundColor: "red",
    color: "white",
    flexDirection: "row",
    justifyContent: "center",
    padding: 10
  },
  thanhtoan: {
    flexDirection: "row",
    justifyContent: "center",
    marginVertical:20
  },
  title: {
    fontSize: 15,
    fontWeight: "bold",
  },
  pricenew:{
    fontSize: 20,
    color:"red",
    fontWeight: "bold",
  },
  priceold:{
    fontSize: 15,
    color:"#808080",
    fontWeight: "bold",
    textDecorationLine: "line-through"
  }
});
